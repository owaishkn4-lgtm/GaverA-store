const CATALOG = {
  tee: 499,
  shirt: 899,
  jeans: 1199,
  hoodie: 1299,
  baggy: 999,
  track: 799,
  fullshirt: 999,
  cargo: 1099,
};

const json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body),
});

export const handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });

  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) return json(500, { error: "Payment service is not configured. Add Razorpay environment variables in Netlify." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Invalid JSON body" }); }

  const items = body.items;
  if (!Array.isArray(items) || items.length < 1 || items.length > 30) {
    return json(400, { error: "Your bag is empty or contains too many items." });
  }

  let totalRupees = 0;
  const receiptItems = [];
  for (const item of items) {
    const unitPrice = CATALOG[item?.id];
    const qty = Number(item?.qty);
    if (!unitPrice || !Number.isInteger(qty) || qty < 1 || qty > 10) {
      return json(400, { error: "One or more cart items are invalid. Please refresh your bag." });
    }
    totalRupees += unitPrice * qty;
    receiptItems.push({ id: item.id, qty, size: String(item.size || "M").slice(0, 8), color: String(item.color || "Black").slice(0, 30) });
  }

  const amount = Math.round(totalRupees * 100);
  if (!Number.isSafeInteger(amount) || amount < 100) return json(400, { error: "Order amount must be at least ₹1.00." });

  const receipt = `gav_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`.slice(0, 40);
  const customer = body.customer && typeof body.customer === "object" ? body.customer : {};
  const payload = {
    amount,
    currency: "INR",
    receipt,
    notes: {
      customer_name: String(customer.name || "").slice(0, 200),
      customer_phone: String(customer.phone || "").slice(0, 20),
      pincode: String(customer.pincode || "").slice(0, 12),
      city: String(customer.city || "").slice(0, 100),
      address: String(customer.address || "").slice(0, 500),
      cart: JSON.stringify(receiptItems).slice(0, 500),
    },
  };

  try {
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      const status = response.status === 401 ? 401 : 500;
      return json(status, { error: status === 401 ? "Razorpay authentication failed. Check the API keys." : (result.error?.description || "Unable to create payment order. Please try again.") });
    }
    return json(200, { order_id: result.id, amount: result.amount, currency: result.currency, key_id: keyId });
  } catch {
    return json(500, { error: "Payment service is temporarily unavailable. Please try again." });
  }
};
