import { createHmac, timingSafeEqual } from "node:crypto";

const json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body),
});

export const handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret) return json(500, { error: "Payment verification is not configured." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Invalid JSON body" }); }

  const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature } = body;
  if (![orderId, paymentId, signature].every(v => typeof v === "string" && v.length > 0)) {
    return json(400, { error: "Missing payment verification fields." });
  }
  if (orderId.length > 100 || paymentId.length > 100 || signature.length > 256) {
    return json(400, { error: "Invalid payment verification fields." });
  }

  const expected = createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    return json(400, { verified: false, error: "Payment signature did not match. Do not treat this order as paid." });
  }
  return json(200, { verified: true, order_id: orderId, payment_id: paymentId });
};
